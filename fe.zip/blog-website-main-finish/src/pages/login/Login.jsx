import React from "react";
import axios from 'axios'; 
import { useHistory } from 'react-router-dom'; 
import "./login.css";
import back from "../../assets/images/my-account.jpg";

export const Login = () => {
  const history = useHistory(); 
  
  const handleLogin = async (event) => {
    event.preventDefault();

    const usernameOrEmail = event.target.elements.username.value;
    const password = event.target.elements.password.value;

    if (!usernameOrEmail || !password) {
      alert("Please enter both username or email address and password.");
    } else {
      try {
        const response = await axios.post('http://localhost:8080/login', {
          username: usernameOrEmail,
          password: password
        });
        alert("Login successful!");
        
        history.push('/home'); 
      } catch (error) {
        console.error('Login error:', error);
        alert("Login failed. Please try again.");
      }
    }
  };

  return (
    <>
      <section className="login">
        <div className="backImg">
          <img src={back} alt="" />
          <div className="text">
            <h3>Login</h3>
          </div>
        </div>

        <form onSubmit={handleLogin}>
          <span>Username or email address *</span>
          <input type="text" name="username" required />
          <span>Password *</span>
          <input type="password" name="password" required />
          <button className="button" type="submit">
            Log in
          </button>
        </form>
      </section>
    </>
  );
};
