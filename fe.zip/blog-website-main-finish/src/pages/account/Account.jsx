import React from "react"
import image from "../../assets/images/profile.jpeg"
import "./account.css"

export const Account = () => {
  return (
    <>
      <section className='accountInfo'>
        <div className='container boxItems'>
          <h1>Account Information</h1>
          <div className='content'>
            <div className='left'>
              <div className='img flexCenter'>
                <input type='file' accept='image/*' src={image} alt='img' />
                <img src={require('../../assets/images/profile.jpeg')} alt='image' class='image-preview' />
              </div>
            </div>
            <div className='right'>
              <label htmlFor=''>Username</label>
              <input type='text' placeholder="Tanvi" />
              <label htmlFor=''>Email</label>
              <input type='email' placeholder="tj@gmail.com" />
            </div>
          </div>
        </div>
      </section>
    </>
  )
}
