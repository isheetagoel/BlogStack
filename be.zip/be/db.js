const mongoose = require('mongoose');

mongoose.connect('mongodb+srv://tanvijain2022:Sxs8vU3eAD42iyQJ@cluster0.e3es0qg.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0', {

});

const db = mongoose.connection;

db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to MongoDB');
});

module.exports = db;
